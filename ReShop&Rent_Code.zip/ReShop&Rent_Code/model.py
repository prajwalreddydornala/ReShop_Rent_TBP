import pandas as pd
import numpy as np

# Plots
import seaborn as sns
sns.set_style("darkgrid")
import matplotlib.pyplot as plt

# Machine Learning
from sklearn.model_selection import StratifiedShuffleSplit, cross_val_score, cross_val_predict
from sklearn.metrics import accuracy_score, confusion_matrix, precision_recall_curve
from sklearn.preprocessing import StandardScaler

from sklearn import linear_model, neighbors, ensemble, tree

#ignore warning messages
import warnings
warnings.filterwarnings('ignore')
data = pd.read_csv("final_test.csv")
data
data.isnull().sum()
data[["size"]].value_counts()
plt.figure(figsize=(10, 6), dpi=80)
sns.countplot(y=data["size"])
plt.show()
data.describe()
data["age"] = data["age"].replace(0, np.nan)
data["age"] = data["age"].fillna(data["age"].median())
data[data["size"] == "XXL"].isnull().sum()
data.dropna(inplace=True)
data.isnull().sum()
data.reset_index(drop=True, inplace=True)
data["height_bins"] = pd.qcut(data["height"], q=6)
data["weight_bins"] = pd.qcut(data["weight"], q=10)
data["age_bins"] = pd.qcut(data["age"], q=10)

data.drop(["weight", "age", "height"], axis=1, inplace=True)
data
split = StratifiedShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
for train_index, test_index in split.split(data, data['size']):
    train = data.loc[train_index]
    test = data.loc[test_index]
X_train = train.drop("size", axis=1)
y_train = train["size"]

X_test = test.drop("size", axis=1)
y_test = test["size"]
X_train = pd.get_dummies(X_train).values
X_test = pd.get_dummies(X_test).values
xgb_clf = tree.DecisionTreeClassifier()

# Training the XGBClassifier
xgb_clf.fit(X_train, y_train)

# KFold Accuracy Score
kfold_accuraies = cross_val_score(xgb_clf, X_train, y_train, cv=10, n_jobs=-1)
print("KFold Accuracies:", kfold_accuraies)
print("Mean KFold Accuracy:", kfold_accuraies.mean())

# Predicting Size for Testing Data
y_pred = cross_val_predict(xgb_clf, X_test, y_test, cv=10, n_jobs=-1)
print(y_pred)

# Accuracy Score
print("Accuracy Score:", accuracy_score(y_test, y_pred))

# Confusion Matrix
plt.figure(figsize=(12, 8), dpi=80)
sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, fmt="d")
plt.show()
## evaluating the model
def predict_price(weight,age,height):
    x = np.zeros(26)
    x[0] = weight
    x[1] = age
    x[2] = height
    x[3:] = [0] * 23
    return xgb_clf.predict([x])[0]
# saving the model
import pickle
with open('sizeprediction.pickle','wb') as f:
    pickle.dump(xgb_clf,f)